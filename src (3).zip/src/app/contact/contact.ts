export interface IContact {
    avatar: string;
    name: string;
    messages: any[];
    time: string;
    status: string;
}
