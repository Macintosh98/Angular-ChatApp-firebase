import { Component, OnInit } from '@angular/core';
import { AngularFireDatabase, ChildEvent, AngularFireList } from 'angularfire2/database';
import { AngularFireAuth } from '@angular/fire/auth';

@Component({
  selector: 'app-projects-list',
  templateUrl: './projects-list.component.html',
  styleUrls: ['./projects-list.component.css']
})
export class ProjectsListComponent implements OnInit {

  myprojects : any;
  name : string;
  description : string;

  constructor(private db: AngularFireDatabase , private afAuth: AngularFireAuth,) {

    console.log("Inside Project list \n These are my projects" )
    this.myprojects = this.db.list(`Users/${this.afAuth.auth.currentUser.uid}/projects`).valueChanges();
    this.myprojects.forEach(project => {
      project.forEach(element => {
        this.getDetails(element['id'])
      });
    });
  }

  ngOnInit() {
  }

  getDetails(projectKey) : any
  {
    let path = 'projects/'+projectKey

    this.db.database.ref(path).on('value' , snap => {
      return snap.val();
        // this.name = snap.val()['name']
        // this.description = snap.val()['description']
    })
  }

}
