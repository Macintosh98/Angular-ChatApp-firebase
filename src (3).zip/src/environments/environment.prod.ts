export const environment = {
  production: true,
  firebase:{
    apiKey: "AIzaSyAGvk1YOjSNBxcHarvKQ7Kgy4WTFUMA99I",
    authDomain: "prodix-b9fff.firebaseapp.com",
    databaseURL: "https://prodix-b9fff.firebaseio.com",
    projectId: "prodix-b9fff",
    storageBucket: "",
    messagingSenderId: "664640416057",
    appId: "1:664640416057:web:77e1301366c0707a"
  }
};
